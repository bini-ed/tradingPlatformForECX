const timer = (timer) => {
  console.log(timer);
};

module.exports = timer;
