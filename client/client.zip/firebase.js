// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAvRzwo6hS0alil7SQDY2gGglRAz62hnLs",
  authDomain: "seniorproject-437c4.firebaseapp.com",
  projectId: "seniorproject-437c4",
  storageBucket: "seniorproject-437c4.appspot.com",
  messagingSenderId: "772411718565",
  appId: "1:772411718565:web:659230d36198800166064c",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
