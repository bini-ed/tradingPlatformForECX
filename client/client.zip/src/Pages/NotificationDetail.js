import React from "react";

const NotificationDetail = () => {
  return <div>NotificationDetail</div>;
};

export default NotificationDetail;
